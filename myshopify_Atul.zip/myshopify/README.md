## My Shopify

This project contains failing tests. Each test has a level called out in test description

+ Fix all the tests in LEVEL-1 and 2 if you are applying for SDET position
+ Fix all the tests in LEVEL-3 if you are applying for Sr.SDET position
+ Any refactoring done is considered as bonus. Please incrementally commit your changes.

## Execute tests using command line

+ Level (1) is completed.
+ In level (2) ShouldAddItemCart method is completed.
