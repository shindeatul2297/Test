import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class HomePageTests {

	@Test(description = "LEVEL-1")
	public void shouldVerifyTitle() {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://testvagrant.myshopify.com/");
		String t = driver.getTitle();

		driver.quit();
		//Here changing the webpage Title as mykart i.e. title of webpage.
		Assert.assertEquals(t, "mykart");  

	}

	@Test(description = "LEVEL-1")
	public void shouldAssertTheVisionOfTheCompany() {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://testvagrant.myshopify.com/");

		HomePage homePage = new HomePage(driver);
		String missionText = homePage.getOurMissionText();

		driver.quit(); /*In this case change elememt path using css of webelement ourMissionText 
                           which give the actual text that we have to assert.*/

		Assert.assertEquals(missionText, "Shopping should be fun, convenient and affordable");

	}
}
