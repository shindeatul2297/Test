import io.github.bonigarcia.wdm.WebDriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class SearchTests {

	@Test(description = "LEVEL-1")
	public void shouldVerifySearchResults() {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://testvagrant.myshopify.com/");
		 

		HomePage homePage = new HomePage(driver);
		String searchtext="ADIDAS";     //Keep ADIDAS searchtext in string.
		homePage.search(searchtext);

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		/*
		 * Here, we assert the webelements using FindElements and passing the value of search 
		      text thst we are searching in the locator.
		 *If the size of findelements  we get 4. as like get a number on in html dom
		     then our assertion is for actual(4 elements) to the expected.
		 */

		Assert.assertEquals(4, driver.findElements(By.xpath("//h3[@class='predictive-search__item-heading h5' and starts-with(text(),"
				+ "'"+searchtext+"')]")).size(), "Verify keyword was found in the search results");
		driver.quit();
	}

}
