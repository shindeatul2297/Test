package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {

	WebDriver driver;

	@FindBy(how = How.CSS, using = "div[class='footer-block__details-content rte']")
	private WebElement ourMissionText;

	@FindBy(how = How.CSS, using = ".icon-search")
	public WebElement searchButton;

	@FindBy(how = How.CSS, using = ".icon-cart")
	public WebElement cartButton;

	@FindBy(how = How.ID, using = "Search-In-Modal")
	public WebElement searchTextBox;



	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getOurMissionText() {
		return ourMissionText.getText().trim();
	}

	public void search(String text) {
		searchButton.click();
		searchTextBox.sendKeys(text);
	}


	public void addProductsToCart(int productsCount) {
		List<WebElement> elements = driver.findElements(By.xpath("//div[@class='price ']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", elements.get(0));

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		for (int i = 0; i < productsCount; i++) {

			WebDriverWait wt = new WebDriverWait(driver,Duration.ofSeconds(10));
			wt.until(ExpectedConditions.elementToBeClickable(elements.get(i))).click();
			
			js.executeScript("arguments[0].click();", elements.get(i));

//			elements.get(i).click();
			new ProductPage(driver).addToCart();


		}
	}
}
