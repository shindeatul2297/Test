package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
	WebDriver driver;

	@FindBy(how = How.CSS, using = ".icon-remove")
	WebElement deleteButton;


	public CartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clearCart() {
		deleteButton.click();
	}

	public int getCartCount() {
		List <WebElement> cartele= driver.findElements(By.cssSelector("tr[class='cart-item']"));
		int cartcount =cartele.size();
		return cartcount;
	}
}
