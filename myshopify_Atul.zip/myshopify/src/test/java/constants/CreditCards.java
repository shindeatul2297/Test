package constants;

import entities.CreditCard;

public class CreditCards {

    public static final CreditCard VISA_CARD =
            new CreditCard(1, "Mr Bean", 1125, 111);
}
